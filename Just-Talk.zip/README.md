<!--https://cdn.discordapp.com/emojis/905827157782200320.png?size=80-->

# <h1 align="center"> <code>[<img src="https://pbs.twimg.com/media/Dsw0HsjWwAA-8fE.jpg" height="110px">](https://portfolio-web-rho-ten.vercel.app/home)⠀Hi there⠀|⠀⠀👋⠀⠀| [<img src="https://spotify-github-profile.kittinanx.com/api/view?uid=uwjnzqtalkghfb2gd7ueltxzb&cover_image=true&theme=novatorem&bar_color=ff0000&bar_color_cover=false" background="#fff" height="110px">](https://open.spotify.com/user/uwjnzqtalkghfb2gd7ueltxzb)</code> </h1>

#### Hello, my name is Jack known as Jack Editz I'm an Editor and Musician and Music Producer and I'm also a Programmer and Cyber Security 

[Contact](JackLxProcoder)
<br>

> [!NOTE]
> * I like pscyhology, dictionary,reading
